﻿namespace MicroServiceTemplate
{
    internal class BaseConfiguration
    {
        public bool SwaggerIsEnabled { get; set; } = false;
    }
}
