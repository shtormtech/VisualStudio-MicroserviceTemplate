﻿namespace $safeprojectname$
{
    internal class BaseConfiguration
    {
        public bool SwaggerIsEnabled { get; set; } = false;
    }
}
