﻿using $safeprojectname$.Config;

namespace $safeprojectname$
{
    /// <summary>
    /// Основная конфигураия сервиса
    /// </summary>
    internal class BaseConfiguration
    {
        public SwaggerConfig SwaggerConfig { get; set; }
    }
}
